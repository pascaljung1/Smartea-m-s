FHEM.filelogcharts = [];
