Install:
cp de.fhem.plist /Library/LaunchDaemon/de.fhem.plist

Activate:
launchctl load /Library/LaunchDaemon/de.fhem.plist

Start
launchctl start de.fhem


See also Forum #81485
